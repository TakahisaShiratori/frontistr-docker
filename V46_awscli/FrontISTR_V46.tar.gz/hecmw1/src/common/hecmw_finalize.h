/*****************************************************************************
 * Copyright (c) 2016 The University of Tokyo
 * This software is released under the MIT License, see LICENSE.txt
 *****************************************************************************/

#ifndef HECMW_FINALIZE_INCLUDED
#define HECMW_FINALIZE_INCLUDED


extern int HECMW_finalize(void);

#endif
