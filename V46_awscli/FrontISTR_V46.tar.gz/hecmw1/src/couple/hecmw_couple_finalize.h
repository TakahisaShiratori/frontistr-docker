/*****************************************************************************
 * Copyright (c) 2016 The University of Tokyo
 * This software is released under the MIT License, see LICENSE.txt
 *****************************************************************************/

#ifndef INC_HECMW_COUPLE_FINALIZE
#define INC_HECMW_COUPLE_FINALIZE

extern int
HECMW_couple_finalize(char *boundary_id);

#endif	/* INC_HECMW_COUPLE_FINALIZE */
