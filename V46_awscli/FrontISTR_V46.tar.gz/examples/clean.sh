#!/bin/sh

./clean_static.sh
./clean_eigen.sh
./clean_heat.sh
./clean_dynamic.sh

