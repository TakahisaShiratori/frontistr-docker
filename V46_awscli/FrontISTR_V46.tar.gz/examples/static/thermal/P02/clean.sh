#!/bin/sh
rm -f *~ *.log *.inp *.res.* FSTR.* *.dist.* hecmw_vis.ini hecmw_ctrl.dat
