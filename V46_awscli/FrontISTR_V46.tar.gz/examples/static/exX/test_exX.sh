#!/bin/sh

export model_2d=""

export model_3d="\
	X361\
	X361_1\
	X361_2\
	X361_3"

export model_shell=""

../test_static_sub2.sh $*

