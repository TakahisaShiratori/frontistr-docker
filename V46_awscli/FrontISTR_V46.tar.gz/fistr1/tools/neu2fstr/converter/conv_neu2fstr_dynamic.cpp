/*****************************************************************************
 * Copyright (c) 2016 The University of Tokyo
 * This software is released under the MIT License, see LICENSE.txt
 *****************************************************************************/
/* conv_neu2fstr_dynamic ver.1.0 */


#include "conv_neu2fstr_dynamic.h"


//=============================================================================
// conv_neu2fstr_dynamic
//=============================================================================


bool conv_neu2fstr_dynamic( CNFData& neu, CHECData& hec )
{
	return false;
}



