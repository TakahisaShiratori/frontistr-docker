#!/bin/sh

export model="\
	D341\
	D342\
	D351\
	D352\
	D361\
	D362"

export model_shell="\
	D731\
	D741"

export analysis="s"
../conv_sub.sh ${1}


